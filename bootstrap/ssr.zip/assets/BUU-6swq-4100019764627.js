import { resolveComponent, mergeProps, withCtx, createTextVNode, createVNode, withModifiers, openBlock, createBlock, createCommentVNode, Fragment, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { A as AppLayout } from "./C8kKQx5k-1940427762604.js";
import _sfc_main$5 from "./D2lwG0sE-6107694471002.js";
import _sfc_main$4 from "./B9hxfwPj-6721447601090.js";
import { S as SectionBorder } from "./Cc0TGfnu-4464127900762.js";
import _sfc_main$3 from "./DJZitVMO-0616140742790.js";
import _sfc_main$2 from "./TCvM3V6j-4779260100164.js";
import _sfc_main$1 from "./9IFpWDU8-6064701204197.js";
import { W as Wrapper } from "./yDxbi3R7-0720941665744.js";
import "@inertiajs/vue3";
import "./BW6cC8iL-6029726174404.js";
import "./kZV6a-x4-4071426709264.js";
import "vuetify";
import "./DKEAH6nn-6049022671474.js";
import "mitt";
import "gsap";
import "gsap/ScrollTrigger.js";
import "gsap/ScrollSmoother.js";
import "./1tPrXgE0-4176206249407.js";
import "./LMSwKBNO-7296410420675.js";
import "./C6q4kDV--6124096474207.js";
import "./DsvTyKEu-4210706942764.js";
import "./CeVcRmCk-7600627194244.js";
import "./Cyl_ukyB-0407127665942.js";
import "./wq5k70lg-4479260246071.js";
import "./CP0T8kCa-7646002442197.js";
import "./s5hiF3bK-1729244760064.js";
import "./DJklk-mW-4477901262460.js";
import "./UWdZNfnI-4417066942720.js";
import "./CMRC4Q_0-4900264642771.js";
import "./Do1v5jZF-9262707410464.js";
import "./CbRRkJ-H-7291204447660.js";
const _sfc_main = {
  __name: "Show",
  __ssrInlineRender: true,
  props: {
    confirmsTwoFactorAuthentication: Boolean,
    sessions: Array
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_v_btn = resolveComponent("v-btn");
      _push(ssrRenderComponent(AppLayout, mergeProps({ title: "Profile" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(Wrapper, { style: { "margin-top": "150px" } }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="flex justify-center"${_scopeId2}><div class="text-center"${_scopeId2}><h1 class="text-6xl brand uppercase"${_scopeId2}>Profile</h1>`);
                  _push3(ssrRenderComponent(_component_v_btn, {
                    onClick: ($event) => _ctx.$inertia.visit(_ctx.route("account")),
                    variant: "plain",
                    color: "black",
                    size: "small"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Back to account`);
                      } else {
                        return [
                          createTextVNode("Back to account")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div><div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8"${_scopeId2}>`);
                  if (_ctx.$page.props.jetstream.canUpdateProfileInformation) {
                    _push3(`<div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$1, {
                      user: _ctx.$page.props.auth.user
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(SectionBorder, null, null, _parent3, _scopeId2));
                    _push3(`</div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  if (_ctx.$page.props.jetstream.canUpdatePassword) {
                    _push3(`<div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$2, { class: "mt-10 sm:mt-0" }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(SectionBorder, null, null, _parent3, _scopeId2));
                    _push3(`</div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  if (_ctx.$page.props.jetstream.canManageTwoFactorAuthentication) {
                    _push3(`<div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      "requires-confirmation": __props.confirmsTwoFactorAuthentication,
                      class: "mt-10 sm:mt-0"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(SectionBorder, null, null, _parent3, _scopeId2));
                    _push3(`</div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    sessions: __props.sessions,
                    class: "mt-10 sm:mt-0"
                  }, null, _parent3, _scopeId2));
                  if (_ctx.$page.props.jetstream.hasAccountDeletionFeatures) {
                    _push3(`<!--[-->`);
                    _push3(ssrRenderComponent(SectionBorder, null, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, { class: "mt-10 sm:mt-0" }, null, _parent3, _scopeId2));
                    _push3(`<!--]-->`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "flex justify-center" }, [
                      createVNode("div", { class: "text-center" }, [
                        createVNode("h1", { class: "text-6xl brand uppercase" }, "Profile"),
                        createVNode(_component_v_btn, {
                          onClick: withModifiers(($event) => _ctx.$inertia.visit(_ctx.route("account")), ["prevent"]),
                          variant: "plain",
                          color: "black",
                          size: "small"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Back to account")
                          ]),
                          _: 1
                        }, 8, ["onClick"])
                      ])
                    ]),
                    createVNode("div", { class: "max-w-7xl mx-auto py-10 sm:px-6 lg:px-8" }, [
                      _ctx.$page.props.jetstream.canUpdateProfileInformation ? (openBlock(), createBlock("div", { key: 0 }, [
                        createVNode(_sfc_main$1, {
                          user: _ctx.$page.props.auth.user
                        }, null, 8, ["user"]),
                        createVNode(SectionBorder)
                      ])) : createCommentVNode("", true),
                      _ctx.$page.props.jetstream.canUpdatePassword ? (openBlock(), createBlock("div", { key: 1 }, [
                        createVNode(_sfc_main$2, { class: "mt-10 sm:mt-0" }),
                        createVNode(SectionBorder)
                      ])) : createCommentVNode("", true),
                      _ctx.$page.props.jetstream.canManageTwoFactorAuthentication ? (openBlock(), createBlock("div", { key: 2 }, [
                        createVNode(_sfc_main$3, {
                          "requires-confirmation": __props.confirmsTwoFactorAuthentication,
                          class: "mt-10 sm:mt-0"
                        }, null, 8, ["requires-confirmation"]),
                        createVNode(SectionBorder)
                      ])) : createCommentVNode("", true),
                      createVNode(_sfc_main$4, {
                        sessions: __props.sessions,
                        class: "mt-10 sm:mt-0"
                      }, null, 8, ["sessions"]),
                      _ctx.$page.props.jetstream.hasAccountDeletionFeatures ? (openBlock(), createBlock(Fragment, { key: 3 }, [
                        createVNode(SectionBorder),
                        createVNode(_sfc_main$5, { class: "mt-10 sm:mt-0" })
                      ], 64)) : createCommentVNode("", true)
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(Wrapper, { style: { "margin-top": "150px" } }, {
                default: withCtx(() => [
                  createVNode("div", { class: "flex justify-center" }, [
                    createVNode("div", { class: "text-center" }, [
                      createVNode("h1", { class: "text-6xl brand uppercase" }, "Profile"),
                      createVNode(_component_v_btn, {
                        onClick: withModifiers(($event) => _ctx.$inertia.visit(_ctx.route("account")), ["prevent"]),
                        variant: "plain",
                        color: "black",
                        size: "small"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Back to account")
                        ]),
                        _: 1
                      }, 8, ["onClick"])
                    ])
                  ]),
                  createVNode("div", { class: "max-w-7xl mx-auto py-10 sm:px-6 lg:px-8" }, [
                    _ctx.$page.props.jetstream.canUpdateProfileInformation ? (openBlock(), createBlock("div", { key: 0 }, [
                      createVNode(_sfc_main$1, {
                        user: _ctx.$page.props.auth.user
                      }, null, 8, ["user"]),
                      createVNode(SectionBorder)
                    ])) : createCommentVNode("", true),
                    _ctx.$page.props.jetstream.canUpdatePassword ? (openBlock(), createBlock("div", { key: 1 }, [
                      createVNode(_sfc_main$2, { class: "mt-10 sm:mt-0" }),
                      createVNode(SectionBorder)
                    ])) : createCommentVNode("", true),
                    _ctx.$page.props.jetstream.canManageTwoFactorAuthentication ? (openBlock(), createBlock("div", { key: 2 }, [
                      createVNode(_sfc_main$3, {
                        "requires-confirmation": __props.confirmsTwoFactorAuthentication,
                        class: "mt-10 sm:mt-0"
                      }, null, 8, ["requires-confirmation"]),
                      createVNode(SectionBorder)
                    ])) : createCommentVNode("", true),
                    createVNode(_sfc_main$4, {
                      sessions: __props.sessions,
                      class: "mt-10 sm:mt-0"
                    }, null, 8, ["sessions"]),
                    _ctx.$page.props.jetstream.hasAccountDeletionFeatures ? (openBlock(), createBlock(Fragment, { key: 3 }, [
                      createVNode(SectionBorder),
                      createVNode(_sfc_main$5, { class: "mt-10 sm:mt-0" })
                    ], 64)) : createCommentVNode("", true)
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Profile/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
