import { mergeProps, withCtx, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import _sfc_main$1 from "./gT_1SfYF-2644676070919.js";
import { A as AppLayout } from "./C8kKQx5k-1940427762604.js";
import "@inertiajs/vue3";
import "./CMRC4Q_0-4900264642771.js";
import "./wq5k70lg-4479260246071.js";
import "./CP0T8kCa-7646002442197.js";
import "./1tPrXgE0-4176206249407.js";
import "./BBcrr1ex-1297704624604.js";
import "./C6q4kDV--6124096474207.js";
import "./s5hiF3bK-1729244760064.js";
import "./DJklk-mW-4477901262460.js";
import "./DKEAH6nn-6049022671474.js";
import "mitt";
import "./CbRRkJ-H-7291204447660.js";
import "./UWdZNfnI-4417066942720.js";
import "./Do1v5jZF-9262707410464.js";
import "./DsvTyKEu-4210706942764.js";
import "./CeVcRmCk-7600627194244.js";
import "./Cc0TGfnu-4464127900762.js";
import "./BW6cC8iL-6029726174404.js";
import "./kZV6a-x4-4071426709264.js";
import "vuetify";
import "gsap";
import "gsap/ScrollTrigger.js";
import "gsap/ScrollSmoother.js";
import "./LMSwKBNO-7296410420675.js";
import "./Cyl_ukyB-0407127665942.js";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    tokens: Array,
    availablePermissions: Array,
    defaultPermissions: Array
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(AppLayout, mergeProps({ title: "API Tokens" }, _attrs), {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="font-semibold text-xl text-gray-800 leading-tight"${_scopeId}> API Tokens </h2>`);
          } else {
            return [
              createVNode("h2", { class: "font-semibold text-xl text-gray-800 leading-tight" }, " API Tokens ")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              tokens: __props.tokens,
              "available-permissions": __props.availablePermissions,
              "default-permissions": __props.defaultPermissions
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto py-10 sm:px-6 lg:px-8" }, [
                  createVNode(_sfc_main$1, {
                    tokens: __props.tokens,
                    "available-permissions": __props.availablePermissions,
                    "default-permissions": __props.defaultPermissions
                  }, null, 8, ["tokens", "available-permissions", "default-permissions"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/API/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
